import{r as request}from"./index.DMht6ZEk.js";const agentChatApi={welcome:agentId=>request(`/agents/${encodeURIComponent(agentId)}/chat/welcome`)};export{agentChatApi as a};
