import{r as request}from"./index.rwh6DgHV.js";const agentChatApi={welcome:agentId=>request(`/agents/${encodeURIComponent(agentId)}/chat/welcome`)};export{agentChatApi as a};
