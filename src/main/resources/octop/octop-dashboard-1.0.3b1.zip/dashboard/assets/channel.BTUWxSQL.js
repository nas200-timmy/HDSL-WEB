import{U as Utils,D as Color}from"./mermaid.core.Cxp4s-lM.js";const channel=(color,channel2)=>Utils.lang.round(Color.parse(color)[channel2]);export{channel as c};
